class Calculator{

func sum(number: Double, number2: Double) -> Double{
return number + number2

}

func SubstracOperation(number: Double, number2: Double) -> Double{
return number - number2

}

func MultiplyOperation(number: Double, number2: Double) -> Double{
return number * number2

}

func DividedOperation(number: Double, number2: Double) -> Double{
return number / number2
    


}

func modOperation(number: Int, number2:
                    Int) -> Int{
return number % number2
}
}


var num1: Double = 5
var num2: Double = 2
let num3: Int = 4
let num4: Int = 6


var c = Calculator()
print(c.sum(number: num1, number2: num2))
print(c.SubstracOperation(number: num1, number2: num2))
print(c.MultiplyOperation(number: num1, number2: num2))
print(c.DividedOperation(number: num1, number2: num2))
print(c.modOperation(number: num3, number2: num4))
var profile = """
"첫번째 값은 \(num1) 입니다."
"두번쨰 값은 \(num2) 입니다."
"더한 값은 \(num1+num2) 입니다."
"뺀 값은 \(num1-num2) 입니다."
"곱한 값은 \(num1*num2) 입니다."
"나눈 값은 \(num1/num2) 입니다."
"""

print(profile)

